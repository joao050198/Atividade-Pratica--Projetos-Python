def preparar_café(tipo):
    print("Preparando...", tipo)
    return "Seu pedido está pronto"

bebida = preparar_café("Com leite")
print(bebida)
from ex import preparar_café

print(preparar_café)

def escreva (msg):
    print(msg)

escreva("Olá, Mundo!")
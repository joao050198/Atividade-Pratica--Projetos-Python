def soma(n1, n2):
    return n1 + n2

soma(3,3)
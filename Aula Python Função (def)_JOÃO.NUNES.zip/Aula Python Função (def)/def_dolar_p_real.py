import

def dolar_p_real(dolar):
    cotacao_real = float(input("Informe Cotação Real: "))
    print(" ________________ ")
    print("|...Calculando...|")
    print("|________________|")
    print(dolar * cotacao_real)
dolar_p_real(50)

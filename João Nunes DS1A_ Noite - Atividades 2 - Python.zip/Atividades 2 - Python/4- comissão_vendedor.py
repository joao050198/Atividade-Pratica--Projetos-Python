import os
os.system ("cls )" )

print("COMISSÃO DE VENDAS")
input("Insira o Nome do Vendedor: ")
valor_vendas = float(input("Insira o valor total das vendas do mês: "))

comissao1 = valor_vendas - (valor_vendas * 0.10)
comissao2 = valor_vendas - (valor_vendas * 0.07)
comissao3 = valor_vendas - (valor_vendas * 0.05)


if (valor_vendas >= 20000):
    print (f"Comissão de 10%, portanto sua parte é: R${comissao1}")
elif (valor_vendas >= 10000):
    print(f"Comissão de 7%, portanto sua parte é: R${comissao2}")
else :
    print(f"Comissão de 5%, portanto sua parte é: R${comissao3}")
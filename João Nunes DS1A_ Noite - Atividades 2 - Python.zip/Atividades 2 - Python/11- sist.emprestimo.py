import os
os.system("cls)")

import time

print("SISTEMA DE IDENTIFICAÇÃO DE SINAIS")

#Passo 1 - Entrada de Dados
salario = float (input("informe o Salário: "))
Parcela = float (input("informe o Valor da Parcela: "))

print("...Verificando...")

time.sleep(4)

if (Parcela <= salario * 0.30):
    print("Empréstimo Aprovado!!!")
else :
    print(f"Empréstimo Recusado!")
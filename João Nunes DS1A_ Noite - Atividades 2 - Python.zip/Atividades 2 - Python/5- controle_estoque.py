import os
os.system ("cls )" )

print("Controle de ESTOQUE")


input("Insira o Nome do Produto: ")
quantidade = int(input("Insira a quantidade: "))

if (quantidade >= 30):
    print ("Estoque Adequado")
elif (quantidade >= 10):
    print("Estoque Baixo!")
else :
    print("Estoque Crítico")
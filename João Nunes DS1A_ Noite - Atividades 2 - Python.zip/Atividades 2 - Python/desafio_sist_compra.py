import os
os.system("cls)")

import time

print("Desconto de Compra")

#Passo 1 - Entrada de Dados
nome_cliente = (input("informe o Nome do Clinte: "))
nome_produto = (input("informe o Nome do Produto: "))
preço_unitário = float (input("informe o Preço Unitário: "))
quantidade = float (input("informe a Quantidade: "))


print("...Verificando...")
time.sleep(2)

subtotal = preço_unitário * quantidade
print (f"o total ficou: {subtotal}")

print("...Verificando...")

time.sleep(2)

desconto15 = subtotal - (subtotal * 0.15)
desconto10 = subtotal - (subtotal * 0.10)
desconto5 =  subtotal - (subtotal * 0.5)

if (subtotal >= 1000):
    print(f"O valor excedeu R$1000, Portanto possui 15% de desconto. O total com desconto fica: R${desconto15}")
elif (subtotal >= 500):
    print(f"O valor excedeu R$500, Portanto possui 10% de desconto. O total fica: R$:{desconto10}")
elif (subtotal >= 200):
    print(f"O valor excedeu R$200, Portanto possui 5% de desconto. O total fica: R$:{desconto5}")
else :
    print(f"Sem desconto! O total fica: R$:{subtotal}")
import os
os.system ("cls )" )


print("DESCONTO FORMA DE PAGAMENTO")

#Passo 1 - Entrada de Dados
valor_compra = float (input("informe o valor da compra: "))
forma_pagamento = input("informe a forma de pagamento: ")

print("...Verificando o desconto...")

pix = valor_compra - (valor_compra*0.10)
dinheiro = valor_compra - (valor_compra*0.05)



if (forma_pagamento == "pix"):
    print(f"Pix tem 10% de desconto. O valor total fica: R$:{pix}")
elif (forma_pagamento == "dinheiro" ):
    print(f"Pix tem 5% de desconto. O valor total fica: R$:{dinheiro}")
else : 
    print("Não Possui desconto")


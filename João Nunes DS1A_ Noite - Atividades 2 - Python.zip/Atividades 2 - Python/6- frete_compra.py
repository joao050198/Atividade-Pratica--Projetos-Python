import os
os.system ("cls )" )


print("FRETE DE COMPRA")

#Passo 1 - Entrada de Dados
valor_compra = float (input("informe o valor da compra: "))

print("...Verificando a inclusão de frete...")

frete = valor_compra + 25


if (valor_compra >= 300):
    print(f"Frete Grátis. O valor total fica: R$:{valor_compra}")
elif (valor_compra < 300):
    print(f"O frete é de R$25. O valor total fica: R$:{frete} ")
else :
    print(f"Coloque um Valor válido!")
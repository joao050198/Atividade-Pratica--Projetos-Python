import os
os.system("cls)")

print("Análise de categoria de cliente")

#Passo 1 - Entrada de Dados
Nome = (input("informe o seu Nome: "))
valor_compra = float (input("informe o valor da compra: "))

print("...Verificando qual Categoria de Cliente você é...")


if (valor_compra >= 5000):
    print("Você é Cliente Ouro!!!")
elif (valor_compra >= 2000):
    print(f"Você é Cliente Prata!!")
else :
    print(f"Você é Cliente Bronze!")
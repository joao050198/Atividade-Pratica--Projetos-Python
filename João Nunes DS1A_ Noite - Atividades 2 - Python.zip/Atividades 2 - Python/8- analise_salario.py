import os
os.system ("cls )" )

print("ANÁLISE DE SALÁRIO")
input("Insira o Nome : ")
salario_atual = float(input("Insira o seu Salário atual: "))

salario1 = salario_atual + (salario_atual * 0.10)
salario2 = salario_atual + (salario_atual * 0.07)
salario3 = salario_atual + (salario_atual * 0.05)


if (salario_atual >= 2000):
    print (f"Aumento de 10%, portanto seu novo Salário: R${salario1}")
elif (salario_atual >= 5000):
    print(f"Aumento de 7%, portanto seu novo Salário: R${salario2}")
else :
    print(f"Aumento de 5%, portanto seu novo Salário: R${salario3}")
import os
os.system("cls)")

print("SISTEMA DE IDENTIFICAÇÃO DE SINAIS")

#Passo 1 - Entrada de Dados
Numero = float (input("informe o Número a ser identificado : "))

print("...Verificando...")


if (Numero > 0):
    print(f"O número {Numero} é positivo")
elif (Numero == 0 ):
    print(f"O número {Numero} é zero(Neutro)")
else :
    print(f"O número {Numero} é negativo")
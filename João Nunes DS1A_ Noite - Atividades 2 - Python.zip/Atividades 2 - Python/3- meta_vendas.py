import os
os.system ("cls )" )

print("META DE VENDAS")
input("Insira o Nome do Vendedor: ")
valor_vendido = float(input("Insira o valor total vendido no mês: "))

if (valor_vendido >= 15000):
    print ("Excelente")
elif (valor_vendido >= 10000):
    print("Meta Atingida!")
else :
    print("Meta não Atingida")
import os
os.system("cls)")

import time

print("Comparação de Preço")

#Passo 1 - Entrada de Dados
Fornecedor1 = (input("informe o Fornecedor1: "))
orcamento1 = float (input("informe o Orçamento1: "))
Fornecedor2 = (input("informe o Fornecedor2: "))
orcamento2 = float (input("informe o Orçamento2: "))

print("...Verificando...")

time.sleep(2)

if (Fornecedor1 < Fornecedor2):
    print(f"O preço menor é do {Fornecedor1}")
elif (Fornecedor2 < Fornecedor1):
    print(f"O preço menor é do {Fornecedor2}")   
else :
    print(f"são iguais!")
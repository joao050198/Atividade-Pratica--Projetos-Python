import os
os.system("cls)")

print("Desconto de Compra")

#Passo 1 - Entrada de Dados
valor_compra = float (input("informe o valor da compra: "))

print("...Verificando se possui Desconto...")

desconto = valor_compra - (valor_compra*0.10)


if (valor_compra >= 500):
    print(f"O valor excedeu R$500, Portanto possui 10% de desconto. O total com desconto fica: R${desconto}")
elif (valor_compra < 500):
    print(f"O valor não excedeu R$500, Portanto não possui desconto. O total fica: R${valor_compra}")
else :
    print(f"O produto é gratuito")
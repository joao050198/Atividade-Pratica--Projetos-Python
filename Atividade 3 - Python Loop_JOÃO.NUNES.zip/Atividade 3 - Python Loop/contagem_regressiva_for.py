import os
os.system("cls")

import time

nome = input("QUal seu nome: ")
numero = int(input("Digite o Número: "))



for i in range(numero,0,-1):
    print (f"{i}")

    
    time.sleep(1)

print("Aperte Enter para finalizar....")
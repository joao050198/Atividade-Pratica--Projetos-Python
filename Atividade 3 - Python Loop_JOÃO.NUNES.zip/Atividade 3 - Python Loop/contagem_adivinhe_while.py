import os
os.system("cls")

import time

nome = input("Qual seu nome: ")
chute = int(input("Tente um número: "))

i = 1

while i > 0:
    if (chute == 5):
        print("Você Acertou!!")
        break
    else :
        chute = int(input("ERROU!! Tente novamente: "))
        i += 1
    
    
import os
os.system("cls")

import time

print("Olá você tem somente 3 vidas!! CUIDADO")

nome = input("Qual seu nome: ")
chute = int(input("Tente um número: "))

vidas = 3

while vidas :
    if (chute == 5):
        print("Você Acertou!!")
        break
    else :
        chute = int(input("ERROU!! Tente novamente: "))
        
    
    
import os
os.system("cls")

import time

nome = input("QUal seu nome: ")
numero = float(input("Digite o Número: "))

i = 1

while i <= 20:
    print (f"{i}")
    i +=1
    
    time.sleep(1)

print("Aperte Enter para finalizar....")
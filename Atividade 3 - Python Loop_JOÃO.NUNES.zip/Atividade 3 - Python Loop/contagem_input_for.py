import os
os.system("cls")

import time

nome = input("QUal seu nome: ")
numero = int(input("Digite o Número: "))



for i in range(1,21):
    print (f"{i}")

    
    time.sleep(1)

print("Aperte Enter para finalizar....")
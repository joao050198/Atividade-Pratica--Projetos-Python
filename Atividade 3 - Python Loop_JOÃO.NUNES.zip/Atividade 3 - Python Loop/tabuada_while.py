import os
os.system("cls")

import time

nome = input("QUal seu nome: ")
numero = float(input("Digite o Número: "))

i = 1

while i <= 10:
    print (f"{i} x {numero} = {i * numero}")
    i +=1
    
    time.sleep(1)

print("Aperte Enter para finalizar....")
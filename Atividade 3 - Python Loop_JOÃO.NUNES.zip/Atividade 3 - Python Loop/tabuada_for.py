import os
os.system("cls")

import time

nome = input("QUal seu nome: ")
numero = float(input("Digite o Número: "))



for i in range(1,11):
    print (f"{i} x {numero} = {i * numero}")

    
    time.sleep(1)

print("Aperte Enter para finalizar....")
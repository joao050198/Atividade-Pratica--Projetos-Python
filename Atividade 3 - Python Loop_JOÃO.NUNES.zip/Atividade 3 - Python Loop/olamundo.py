Palavra = input("Coloque uma palavra: ")
quantidade = int(input("Selecione a quantidade de vezes: "))

i = 1

while i <= quantidade:
    print(f"{Palavra}")
    i += 1
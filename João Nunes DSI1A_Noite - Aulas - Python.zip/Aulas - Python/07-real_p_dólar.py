import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

real = float (input("Informe o valor em Real para ser convertido: R$ "))
cotação_dolar = float (input("Informe a cotação em Dólar atual: "))
dólar = (real / cotação_dolar)

print(f"Olá {Nome}, o valor convertido para dólar é: US$ {dólar}") 
import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

celsius = float (input("Informe a temperatura em Celsius: "))

farenheit = (9 * celsius + 160)/5

print(f"Olá {Nome}, a temperatura em farenheit é {farenheit}°F") 
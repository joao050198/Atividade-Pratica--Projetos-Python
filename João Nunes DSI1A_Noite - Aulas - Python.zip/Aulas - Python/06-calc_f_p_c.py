import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

fahrenheit = float (input("Informe a temperatura em fahrenheit: "))

celsius = (fahrenheit - 32) * 5/9

print(f"Olá {Nome}, a temperatura em farenheit é {celsius}°C") 
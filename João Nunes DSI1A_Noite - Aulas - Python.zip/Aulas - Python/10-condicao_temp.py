import os
os.system("cls)")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

Temperatura = float(input("Informe a temperatura: "))

if (Temperatura >= 30):
    print("Está Quente!!")
if (30 > Temperatura >= 20):
    print("Está Agradável!")
if (Temperatura < 20):
    print("Está Frio!!")
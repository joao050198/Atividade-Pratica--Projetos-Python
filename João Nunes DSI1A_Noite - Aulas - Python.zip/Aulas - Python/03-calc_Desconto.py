import os
os.system("cls)")

print("Calculadora Máxima")

#Passo 1 - Entrada de Dados
Nome_do_Produto = input("informe nome do Produto: ")

numero01 = float (input("Informe o Valor da compra: "))
numero02 = float (input("Informe o Desconto da compra: "))

porcentagem = numero01 * numero02/100
total = numero01 - porcentagem

print(f"O {Nome_do_Produto} tem o desconto de {porcentagem}") 
print(f"Valor a pagar é {total}")


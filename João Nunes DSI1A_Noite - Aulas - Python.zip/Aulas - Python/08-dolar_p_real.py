import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

dólar = float (input("Informe o valor em Dólar para ser convertido: US$ "))
cotação_real = float (input("Informe a cotação em Real atual: "))
real = (dólar * cotação_real)

print(f"Olá {Nome}, o valor convertido para Real é: R$ {real}") 
import os
os.system("cls)")

print("Calculadora Máxima")

#Passo 1 - Entrada de Dados
nome = input("informe seu nome: ")

numero01 = int (input("Informe o 1° valor: "))
numero02 = int (input("Informe o 2° valor: "))

Operação = input("Escolha sua operação - soma,subtração, Multiplicação, Divisão: ")

soma = numero01 + numero02
subtração = numero01 - numero02
Multiplicação = numero01 * numero02
Divisão = numero01 / numero02

#Passo 2 - Processamento

if (Operação == "soma"):
    soma = numero01 + numero02
if (Operação == "subtração"):
    subtração = numero01 - numero02
if (Operação == "Multiplicação"):
    Multiplicação = numero01 * numero02
if (Operação == "Divisão"):
    Divisão = numero01 / numero02
else : print("Erro")



#Passo 3 - Saída

print("-----------------------------------------")
print(f"Olá {nome} o total é {soma}")
print(f"Olá {nome} o total é {subtração}")
print(f"Olá {nome} o total é {Multiplicação}")
print(f"Olá {nome} o total é {Divisão}")
input("Pressione o enter para encerrar...")
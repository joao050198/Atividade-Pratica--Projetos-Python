import os
os.system("cls)")

print("SISTEMA DE AVALIAÇÃO ESCOLAR - FABPRO ")

#Passo 1 - Entrada de Dados
Nome_do_Aluno = input("informe o Nome do Aluno : ")

nota_1 = float (input("Informe a 1° nota: "))
nota_2 = float (input("Informe a 2° nota: "))
nota_3 = float (input("Informe a 3° nota: "))

Média = (nota_1 + nota_2 + nota_3)/3

print("...Calculando...")


if (Média >= 7):
    print(f"A médio do Aluno {Nome_do_Aluno} é {Média:.2f} e ele está Aprovado!!")
elif (7 > Média > 4 ):
    print(f"A médio do Aluno {Nome_do_Aluno} é {Média:.2f} e ele está de Recuperação!!")
else :
    print(f"A médio do Aluno {Nome_do_Aluno} é {Média:.2f} e ele está REPROVADO!!!")


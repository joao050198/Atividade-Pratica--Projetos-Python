import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

peso = float (input("Informe o seu Peso: "))
altura = float (input("Informe a sua altura: "))

IMC = peso/(altura * altura)

if (IMC < 18.5):
    print("Você está abaixo do Peso!")
if (18.5 <= IMC <= 24.9):
    print("Seu Peso está Adequado!")
if (24.9 <= IMC <= 29.9):
    print("Você está acima do Peso!")
elif (IMC > 29.9):
    print("Obesidade")


print(f"Olá {Nome} o seu IMC é {IMC}") 

import os
os.system("cls)")

print("IMC Máxima")

#Passo 1 - Entrada de Dados
Nome = input("informe seu nome : ")

Nascimento_ano = int (input("Informe o Ano em que nasceu: "))
Ano_atual = int (input("Informe o Ano em que estamos: "))
idade = (Ano_atual - Nascimento_ano)

print(f"Olá {Nome}, sua idade é: {idade}") 

if (idade < 18):
    print("Você é Menor de Idade")
if (idade >= 18):
    print("Você já é Maior de Idade!")
elif (idade <= 0):
    print("ERRORRR")


if (idade >= 18):
    carteira = (input("Já possui carteira de Motorista? Se sim digite 1, caso não tiver digite 0: "))
if (carteira == "1"):
    print("Você já pode dirigir!")
elif (carteira == "0"):
    print ("Você não pode dirigir")






#Desafio  > verificar se é maior ou menor de idade